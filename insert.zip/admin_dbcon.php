<?php
 $dbcon=mysqli_connect("localhost","root","","web_student");
?>